import astrbot.api.message_components as comp
from astrbot.api import AstrBotConfig, FunctionTool, logger
from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.star import Context, Star, register

from .tools import SmartSearchTool, SmartSearchBatchTool, get_engine_registry


@register(
    "smartsearch_fallback",
    "smartsearch_fallback",
    "可配置优先/兜底引擎的智能搜索工具（内置 bocha/anysearch + 自定义引擎 + 可选 LLM 结果验证）",
    "1.6.0",
    "https://github.com/your/repo",
)
class SmartSearchFallbackPlugin(Star):
    def __init__(self, context: Context, config: AstrBotConfig = None):
        super().__init__(context)
        self.config = config or {}
        self.plugin_config = dict(self.config)
        self.tools = [
            SmartSearchTool(plugin_config=self.plugin_config),
            SmartSearchBatchTool(plugin_config=self.plugin_config),
        ]
        self.context.add_llm_tools(*self.tools)
        engines = get_engine_registry()
        llm_verify = "启用" if self.plugin_config.get("llm_verifier_enabled") else "关闭"
        llm_model = str(self.plugin_config.get("llm_verifier_provider_id") or "AStrBot当前LLM")
        logger.info(
            f"smartsearch_fallback 已注册: smart_search / smart_search_batch "
            f"(优先={self.plugin_config.get('primary_engine', 'bocha')}, "
            f"兜底={self.plugin_config.get('fallback_engine', 'anysearch')}, "
            f"LLM结果验证={llm_verify}({llm_model}), "
            f"可用引擎={', '.join(sorted(engines.keys())) or '无'})"
        )

    @filter.command("smartsearch")
    async def smartsearch_cmd(self, event: AstrMessageEvent, query: str):
        """手动触发: /smartsearch <query>"""
        try:
            # 手动调用时构造最小 context 壳：直接读全局配置
            result = await SmartSearchTool(plugin_config=self.plugin_config).call(self._fake_context(), query=query)
            yield event.plain_result(result)
        except Exception as e:
            logger.error(f"smartsearch 手动调用失败: {e}")
            yield event.plain_result(f"搜索失败: {e}")

    def _fake_context(self):
        """为手动命令构造兼容 context 壳。"""
        class _AgentCtx:
            context = self.context
            event = None
        class _Ctx:
            context = _AgentCtx()
        return _Ctx()
